// Optional. If you host the front-end on a static host (GitHub Pages, Netlify, Vercel)
// but want shared data + scheduled emails, deploy the server (Render/Railway/Fly/Replit/Glitch)
// and put its address here, e.g. apiBase: 'https://my-tracker.onrender.com'
// Leave blank to use the same address as the page (server mode) or browser-only mode (static hosts).
window.APP_CONFIG = { apiBase: '' };
